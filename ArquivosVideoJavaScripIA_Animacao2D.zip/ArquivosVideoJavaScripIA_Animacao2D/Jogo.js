var canvas = document.getElementById("meuCanvas");
var context = canvas.getContext("2d");
var jogoRodando = true;
const sprites = [];

var jogo = {
  largura: canvas.width,
  altura: canvas.height,
  chao: null,
  posicaoChao: 0,
  x: 0,
  frameIndex: 0,
  tickCount: 0,
  ticksPerFrame: 16,
  numberOfFrames: 8,

  initialize: function() {
    
    const FelinoSpriteSheet = new Image();
    FelinoSpriteSheet.onload = () => {
      const spriteWidth = FelinoSpriteSheet.width / 2;
      const spriteHeight = FelinoSpriteSheet.height / 4;

      for (let row = 0; row < 4; row++) {
        for (let col = 0; col < 2; col++) {
          const sprite = document.createElement('canvas');
          sprite.width = spriteWidth;
          sprite.height = spriteHeight;

          const spriteContext = sprite.getContext('2d');
          spriteContext.drawImage(
            FelinoSpriteSheet,
            col * spriteWidth,
            row * spriteHeight,
            spriteWidth,
            spriteHeight,
            0,
            0,
            spriteWidth,
            spriteHeight
          );

          sprites.push(sprite);
        }
      }

      this.run();
    };
    FelinoSpriteSheet.src = 'FelinoSpriteSheet.png';

    const ChaoSpriteSheet = new Image();
    
    ChaoSpriteSheet.id = "chao01"; 
    ChaoSpriteSheet.style.position = "absolute";
    ChaoSpriteSheet.style.bottom = "0"; 
    ChaoSpriteSheet.style.left = "0"; 
    ChaoSpriteSheet.style.zIndex = "1000"; 

    ChaoSpriteSheet.onload = () => {
      this.chao = ChaoSpriteSheet;
      this.run();
    };
    ChaoSpriteSheet.src = 'ChãoSprite1.png';    


  },

  input: function() {},

  update: function() {
  // Atualize a posição do chão
  this.posicaoChao += 3; // A velocidade do movimento do chão

    this.tickCount++;
    if (this.tickCount > this.ticksPerFrame) {
      this.tickCount = 0;
      if (this.frameIndex < this.numberOfFrames - 1) {
        this.frameIndex++;
      } else {
        this.frameIndex = 0;
      }
    }
  },

  draw: function() {

    context.clearRect(this.x, 245, sprites[this.frameIndex].width, sprites[this.frameIndex].height);

    // Desenhe o chão
    const chaoWidth = this.chao.width / 4; // A largura de cada sprite do chão
    const chaoHeight = this.chao.height;
    const chaoX = -(this.posicaoChao % chaoWidth); // O deslocamento em x para dar a sensação de movimento
    const chaoY = (this.altura - chaoHeight) ;

    context.drawImage(sprites[this.frameIndex], this.x, 245);

    context.drawImage(this.chao, chaoX, chaoY);
    context.drawImage(this.chao, chaoX + chaoWidth, chaoY);

  },

  run: function() {
    let previousTime = 0;

    const loop = (currentTime) => {
      const elapsedTime = currentTime - previousTime;
        this.update();
        this.draw();

      previousTime = currentTime;

      window.requestAnimationFrame(loop);
    };

    window.requestAnimationFrame(loop);
  }
};

jogo.initialize();

window.requestAnimationFrame(jogo.run.bind(jogo));
